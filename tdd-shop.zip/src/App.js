import Order from "./pages/order/Order";
function App() {
  return (
    <div>
      <Order />
    </div>
  );
}

export default App;
