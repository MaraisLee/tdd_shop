import React from "react";

const Option = ({ name }) => {
  return (
    <div>
      <form>
        <input type="checkbox" id={name} />
        <label htmlFor={name}>{name}</label>
      </form>
    </div>
  );
};

export default Option;
